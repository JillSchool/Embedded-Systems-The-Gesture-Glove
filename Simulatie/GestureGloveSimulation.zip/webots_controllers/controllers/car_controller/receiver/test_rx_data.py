
from typing import Final

def decode_data(data: str) -> list[str] | None:
    """
    Decode the received data from the BLE device.

    Args:
        data (str): The data received from the BLE device.

    Returns:
        str: The decoded data.
    """
    # Glove states, 10 bits
    GLOVE_STATE_HW_INTERRUPT: Final[int] = 0b1000000000 
    GLOVE_STATE_FIST_CLOSED: Final[int] = 0b0100000000 
    GLOVE_STATE_NOT_IMPLEMENTED_4: Final[int] = 0b0010000000
    GLOVE_STATE_NOT_IMPLEMENTED_3: Final[int] = 0b0001000000
    GLOVE_STATE_NOT_IMPLEMENTED_2: Final[int] = 0b0000100000
    GLOVE_STATE_NOT_IMPLEMENTED_1: Final[int] = 0b0000010000
    GLOVE_STATE_RIGHT: Final[int] = 0b0000001000
    GLOVE_STATE_LEFT: Final[int] = 0b0000000100
    GLOVE_STATE_UP: Final[int] = 0b0000000010
    GLOVE_STATE_DOWN: Final[int] = 0b0000000001
    GLOVE_STATE_INITIAL: Final[int] = 0b0000000000

    # Webots command strings
    WEBOTS_CMD_FORMAT_LEFT: Final[str] = "A,{0}"
    WEBOTS_CMD_FORMAT_RIGHT: Final[str] = "A,{0}"
    WEBOTS_CMD_FORMAT_PARK: Final[str] = "P"
    WEBOTS_CMD_FORMAT_FORWARD: Final[str] = "D,{0}"
    WEBOTS_CMD_FORMAT_BACKWARD: Final[str] = "D,{0}"

    WEBOTS_CMD_MAX_ANGLE: Final[int] = 30 # Maximum angle for Webots command
    WEBOTS_CMD_MAX_SPEED: Final[int] = 10 # Maximum angle for Webots command

    # create a variable called glove_state_bitmask and decode the string data to an 10bit integer
    glove_state_bitmask: int = int(data, 2)
    result_str_arr: list[str | None] = []

    # Map the glove state bitmask to Webots commands
    if (glove_state_bitmask & GLOVE_STATE_HW_INTERRUPT) or (glove_state_bitmask & GLOVE_STATE_FIST_CLOSED):
        result_str_arr.append(WEBOTS_CMD_FORMAT_PARK)
    elif (glove_state_bitmask == GLOVE_STATE_INITIAL) or not ((glove_state_bitmask & GLOVE_STATE_UP) or (glove_state_bitmask & GLOVE_STATE_DOWN) or (glove_state_bitmask & GLOVE_STATE_LEFT) or (glove_state_bitmask & GLOVE_STATE_RIGHT)):
        result_str_arr.append(None)
    else:
        if glove_state_bitmask & GLOVE_STATE_DOWN:
            result_str_arr.append(WEBOTS_CMD_FORMAT_FORWARD.format(WEBOTS_CMD_MAX_SPEED))
        elif glove_state_bitmask & GLOVE_STATE_UP:
            result_str_arr.append(WEBOTS_CMD_FORMAT_BACKWARD.format(-WEBOTS_CMD_MAX_SPEED))
        else:
            result_str_arr.append(WEBOTS_CMD_FORMAT_FORWARD.format(0))

        if glove_state_bitmask & GLOVE_STATE_LEFT:
            result_str_arr.append(WEBOTS_CMD_FORMAT_LEFT.format(-WEBOTS_CMD_MAX_ANGLE))
        elif glove_state_bitmask & GLOVE_STATE_RIGHT:
            result_str_arr.append(WEBOTS_CMD_FORMAT_RIGHT.format(WEBOTS_CMD_MAX_ANGLE))
        else:
            result_str_arr.append(WEBOTS_CMD_FORMAT_LEFT.format(0))

    results: list[str] = [element for element in result_str_arr if element is not None]

    # Return the decoded string or None if empty
    return results or None

def test_decode_data():
    """
    Test the decode_data function with different inputs.
    """
    test_cases = [
        ("0000000000", None),  # No movement
        ("1000000000", ["P"]),  # Hardware interrupt
        ("0100000000", ["P"]),  # Fist closed
        
        ("0010000000", None),  # Not implemented (ignored)
        ("0001000000", None),  # Not implemented (ignored)
        ("0000100000", None),  # Not implemented (ignored)
        ("0000010000", None),  # Not implemented (ignored)

        ("0000001000", ["D,0", "A,30"]),  # Right turn
        ("0000000100", ["D,0", "A,-30"]),  # Left turn

        ("0000000010", ["D,-10", "A,0"]),  # Backward movement
        ("0000000001", ["D,10", "A,0"]),  # Forward movement

        ("1100000000", ["P"]),  # Hardware interrupt and fist closed
        ("1111111111", ["P"]),  # All states (hardware interrupt and fist closed)
        ("1111111100", ["P"]),  # Forward and left turn
        ("1111110010", ["P"]),  # Backward and right turn
        ("1010101010", ["P"]),  # Mixed states (ignored)

        ("0000001010", ["D,-10", "A,30"]),  # Right turn with backward movement
        ("0000001001", ["D,10", "A,30"]),  # Right turn with forward movement

        ("0000000110", ["D,-10", "A,-30"]),  # Left turn with backward movement
        ("0000000101", ["D,10", "A,-30"]),  # Left turn with forward movement

        ("0011111010", ["D,-10", "A,30"]),  # Right turn with backward movement with unused bits
        ("0011110101", ["D,10", "A,-30"]),  # Left turn with forward movement with unused bits
        
        ("0011110110", ["D,-10", "A,-30"]),  # Left turn with backward movement with unused bits
        ("0011111001", ["D,10", "A,30"]),  # Right turn with forward movement with unused bits
    ]

    for data, expected in test_cases:
        results = decode_data(data)
        if results:
            print(f"Input: {data} => Output: {results}")
            assert results == expected, f"Expected {expected}, but got {results}"

if __name__ == "__main__":
    test_decode_data()
    print("All tests passed!")